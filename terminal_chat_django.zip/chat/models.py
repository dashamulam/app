from django.db import models
# No persistent models required for this simple broadcast chat.
