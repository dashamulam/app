#!/bin/bash
source venv/bin/activate || true
python manage.py migrate
python manage.py collectstatic --noinput
# start Daphne on port 45783
daphne -b 0.0.0.0 -p 45783 terminal_chat_pro.asgi:application
