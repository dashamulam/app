const statusEl = document.getElementById('status');
const log = document.getElementById('log');
const msgInput = document.getElementById('msg');
const sendBtn = document.getElementById('send');
const fileInput = document.getElementById('file');
let username = prompt('Enter username') || 'anon';

function append(html){ const d = document.createElement('div'); d.className = 'line'; d.innerHTML = html; log.appendChild(d); log.scrollTop = log.scrollHeight; }

function setStatus(s){ statusEl.innerText = s; }

const protocol = (window.location.protocol === 'https:') ? 'wss' : 'ws';
const wsUrl = protocol + '://' + window.location.host + '/ws/chat/';
const socket = new WebSocket(wsUrl);

socket.addEventListener('open', ()=>{ setStatus('connected'); append('<span class="sys">Connected to server</span>'); });
socket.addEventListener('close', ()=>{ setStatus('disconnected'); append('<span class="sys">Disconnected</span>'); });
socket.addEventListener('error', (e)=>{ setStatus('error'); append('<span class="sys">Connection error</span>'); });

socket.addEventListener('message', (ev)=>{
  try{ const data = JSON.parse(ev.data); append(data.message); } catch(e){ console.error(e); }
});

sendBtn.onclick = async ()=>{
  const text = msgInput.value.trim();
  const file = fileInput.files[0];
  if(file){
    const b = await toBase64(file);
    const b64 = b.split(',')[1];
    socket.send(JSON.stringify({type:'file', username, filename: file.name, data: b64}));
    fileInput.value = '';
  } else if(text){
    socket.send(JSON.stringify({type:'text', username, message: text}));
    msgInput.value = '';
  }
};

function toBase64(file){ return new Promise((res,rej)=>{ const r=new FileReader(); r.onload=()=>res(r.result); r.onerror=rej; r.readAsDataURL(file); }); }
