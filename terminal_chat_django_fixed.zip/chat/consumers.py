import json
from channels.generic.websocket import AsyncWebsocketConsumer

class ChatConsumer(AsyncWebsocketConsumer):
    async def connect(self):
        self.room_group_name = 'global_chat'
        await self.channel_layer.group_add(self.room_group_name, self.channel_name)
        await self.accept()
        await self.channel_layer.group_send(self.room_group_name, {
            'type': 'chat_message',
            'message': 'System: A user joined the chat.'
        })

    async def disconnect(self, close_code):
        await self.channel_layer.group_send(self.room_group_name, {
            'type': 'chat_message',
            'message': 'System: A user left the chat.'
        })
        await self.channel_layer.group_discard(self.room_group_name, self.channel_name)

    async def receive(self, text_data=None, bytes_data=None):
        if text_data:
            data = json.loads(text_data)
            username = data.get('username', 'anon')
            mtype = data.get('type', 'text')
            if mtype == 'file':
                filename = data.get('filename')
                filedata = data.get('data')  # base64 string without data: prefix
                msg = {
                    'html': f"<span class='meta'>[{username}]</span> sent file: <a href=\"data:application/octet-stream;base64,{filedata}\" download=\"{filename}\">{filename}</a>"
                }
            else:
                message = data.get('message', '')
                msg = {'html': f"<span class='meta'>[{username}]</span> {message}"}
            await self.channel_layer.group_send(self.room_group_name, {
                'type': 'chat_message',
                'message': msg['html']
            })

    async def chat_message(self, event):
        await self.send(text_data=json.dumps({
            'message': event['message']
        }))
