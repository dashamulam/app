Terminal Chat (Django + Channels)
--------------------------------
This is a minimal Django Channels chat app with a green-on-black 'terminal' UI.
It supports real-time messaging and file sending via WebSocket.

Quick start (local):
1. Create a virtualenv and activate it
   python -m venv venv
   source venv/bin/activate  (or venv\Scripts\activate on Windows)

2. Install requirements:
   pip install -r requirements.txt

3. (Optional) If you want Redis for channel layers:
   - Run redis-server locally and set REDIS_URL, e.g. redis://127.0.0.1:6379
   export REDIS_URL=redis://127.0.0.1:6379

4. Run migrations and start dev server:
   python manage.py migrate
   python manage.py runserver

5. Open http://127.0.0.1:8000/

Deploy:
- A Dockerfile is included for Cloud Run. If using Redis in production, use Memorystore and set REDIS_URL env var.
